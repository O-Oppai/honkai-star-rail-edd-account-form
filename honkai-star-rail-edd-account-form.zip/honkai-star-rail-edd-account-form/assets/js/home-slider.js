(function () {
	'use strict';

	function initSlider(root) {
		var viewport = root.querySelector('[data-hsr-slider-viewport]');
		if (!viewport) {
			return;
		}

		var prev = root.querySelector('[data-hsr-slider-prev]');
		var next = root.querySelector('[data-hsr-slider-next]');
		var amount = function () {
			return Math.max(240, Math.round(viewport.clientWidth * 0.8));
		};

		if (prev) {
			prev.addEventListener('click', function () {
				viewport.scrollBy({ left: -amount(), behavior: 'smooth' });
			});
		}

		if (next) {
			next.addEventListener('click', function () {
				viewport.scrollBy({ left: amount(), behavior: 'smooth' });
			});
		}
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('[data-hsr-home-slider]').forEach(initSlider);
	});
})();
