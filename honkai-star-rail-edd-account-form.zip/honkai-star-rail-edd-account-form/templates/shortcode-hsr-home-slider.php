<?php
/**
 * Home slider shortcode template.
 *
 * @var array<int,array<string,mixed>> $cards
 * @var array<string,mixed>            $atts
 * @var string                         $slider_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section id="<?php echo esc_attr( $slider_id ); ?>" class="hsr-home-slider" dir="rtl" data-hsr-home-slider>
	<div class="hsr-home-slider__head">
		<div class="hsr-home-slider__head-text">
			<h3 class="hsr-home-slider__title"><?php echo esc_html( (string) $atts['title'] ); ?></h3>
			<?php if ( ! empty( $atts['description'] ) ) : ?>
				<p class="hsr-home-slider__description"><?php echo esc_html( (string) $atts['description'] ); ?></p>
			<?php endif; ?>
		</div>
		<a class="hsr-home-slider__button" href="<?php echo esc_url( (string) $atts['button_url'] ); ?>"><?php echo esc_html( (string) $atts['button_text'] ); ?></a>
	</div>

	<div class="hsr-home-slider__wrap">
		<button type="button" class="hsr-home-slider__nav is-prev" data-hsr-slider-prev aria-label="قبلی">‹</button>
		<div class="hsr-home-slider__viewport" data-hsr-slider-viewport>
			<div class="hsr-home-slider__track">
				<?php foreach ( $cards as $card_data ) : ?>
					<div class="hsr-home-slider__slide">
						<?php require HSR_EDD_FORM_DIR . 'templates/partials/product-card.php'; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<button type="button" class="hsr-home-slider__nav is-next" data-hsr-slider-next aria-label="بعدی">›</button>
	</div>
</section>
